-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-09-2023 a las 18:46:01
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `policias_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `circuitos`
--

CREATE TABLE `circuitos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_circuito` varchar(255) NOT NULL,
  `codigo_circuito` varchar(255) NOT NULL,
  `numero_circuito` varchar(255) NOT NULL,
  `id_parroquia` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `circuitos`
--

INSERT INTO `circuitos` (`id`, `nombre_circuito`, `codigo_circuito`, `numero_circuito`, `id_parroquia`, `id_usuario`, `created_at`, `updated_at`) VALUES
(1, 'VILCABAMBA', '11D01C01', '22', 1, 1, '2023-07-25 07:35:28', '2023-07-25 07:35:28'),
(2, 'YANGANA', '11D01C02', '22', 2, 1, '2023-07-25 07:35:53', '2023-07-25 07:35:53'),
(3, 'MALACATOS', '11D01C03', '22', 3, 1, '2023-07-25 07:36:17', '2023-07-25 07:36:17'),
(4, 'TAQUIL', '11D01C04', '22', 4, 1, '2023-07-25 07:37:12', '2023-07-25 07:37:12'),
(5, 'TAQUIL', '11D01C04', '22', 5, 1, '2023-07-25 07:37:22', '2023-07-25 07:38:42'),
(6, 'ZAMORA HUAYCO', '11D01C05', '22', 6, 1, '2023-07-27 08:56:23', '2023-07-27 08:56:23'),
(7, 'ESTEBAN GODOY', '11D01C06', '22', 6, 1, '2023-07-27 08:56:56', '2023-07-27 08:56:56'),
(8, 'EL PARAISO', '11D01C07', '22', 6, 1, '2023-07-27 08:57:17', '2023-07-27 08:57:17'),
(9, 'CELI ROMAN', '11D01C08', '22', 6, 1, '2023-07-27 08:57:34', '2023-07-27 08:57:34'),
(10, 'IV CENTENARIO', '11D01C09', '22', 6, 1, '2023-07-27 08:57:56', '2023-07-27 08:57:56'),
(11, 'TEBAIDA', '11D01C10', '22', 6, 1, '2023-07-27 08:58:14', '2023-07-27 08:58:14'),
(12, 'LOS MOLINOS', '11D01C11', '22', 6, 1, '2023-07-27 08:58:33', '2023-07-27 08:58:33'),
(13, 'CHONTACRUZ', '11D01C12', '22', 6, 1, '2023-07-27 08:58:50', '2023-07-27 08:58:50'),
(16, 'EL TAMBO', '11D02C01', '9', 16, 1, '2023-07-27 10:14:16', '2023-07-27 10:14:16'),
(17, 'CATAMAYO NORTE', '11D02C02', '9', 17, 1, '2023-07-27 10:14:35', '2023-07-27 10:14:35'),
(18, 'CATAMAYO SAN JOSE', '11D02C03', '9', 17, 1, '2023-07-27 10:15:28', '2023-07-27 10:15:28'),
(19, 'GUAYQUICHUMA', '11D02C04', '9', 18, 1, '2023-07-27 10:15:57', '2023-07-27 10:15:57'),
(20, 'SAN PEDRO DE LA BENDITA', '11D02C05', '9', 20, 1, '2023-07-27 10:16:10', '2023-07-27 10:16:10'),
(21, 'CHAGUARPAMBA', '11D02C06S01', '9', 21, 1, '2023-07-27 10:16:37', '2023-07-28 23:44:48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `danosfrecuentes`
--

CREATE TABLE `danosfrecuentes` (
  `id` int(10) UNSIGNED NOT NULL,
  `defecto` varchar(255) DEFAULT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `recomendaciones` varchar(255) DEFAULT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_vehiculos` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dependencias`
--

CREATE TABLE `dependencias` (
  `id` int(10) UNSIGNED NOT NULL,
  `provincia` varchar(255) NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_distrito` int(10) UNSIGNED NOT NULL,
  `id_parroquia` int(10) UNSIGNED NOT NULL,
  `id_circuito` int(10) UNSIGNED NOT NULL,
  `id_subcircuito` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `dependencias`
--

INSERT INTO `dependencias` (`id`, `provincia`, `id_usuario`, `id_distrito`, `id_parroquia`, `id_circuito`, `id_subcircuito`, `created_at`, `updated_at`) VALUES
(4, 'LOJA', 1, 1, 1, 1, 1, '2023-07-27 10:20:37', '2023-07-27 10:20:37'),
(5, 'LOJA', 1, 1, 2, 2, 2, '2023-07-27 10:20:41', '2023-07-27 10:20:41'),
(6, 'LOJA', 1, 1, 3, 3, 3, '2023-07-27 10:20:44', '2023-07-27 10:20:44'),
(7, 'LOJA', 1, 1, 4, 4, 4, '2023-07-27 10:20:48', '2023-07-27 10:20:48'),
(8, 'LOJA', 1, 1, 4, 4, 4, '2023-07-27 10:20:49', '2023-07-27 10:20:49'),
(9, 'LOJA', 1, 1, 5, 5, 5, '2023-07-27 10:20:56', '2023-07-27 10:20:56'),
(10, 'LOJA', 1, 1, 6, 6, 6, '2023-07-27 10:21:02', '2023-07-27 10:21:02'),
(11, 'LOJA', 1, 1, 6, 7, 7, '2023-07-27 10:21:09', '2023-07-27 10:21:09'),
(12, 'LOJA', 1, 1, 6, 7, 8, '2023-07-27 10:21:21', '2023-07-27 10:21:21'),
(13, 'LOJA', 1, 1, 6, 8, 9, '2023-07-27 10:21:28', '2023-07-27 10:21:28'),
(14, 'LOJA', 1, 1, 6, 9, 10, '2023-07-27 10:21:35', '2023-07-27 10:21:35'),
(15, 'LOJA', 1, 1, 6, 9, 10, '2023-07-27 10:21:44', '2023-07-27 10:21:44'),
(16, 'LOJA', 1, 1, 6, 10, 11, '2023-07-27 10:21:52', '2023-07-27 10:21:52'),
(17, 'LOJA', 1, 1, 6, 11, 12, '2023-07-27 10:22:00', '2023-07-27 10:22:00'),
(18, 'LOJA', 1, 1, 6, 12, 13, '2023-07-27 10:22:08', '2023-07-27 10:22:08'),
(19, 'LOJA', 1, 1, 6, 13, 14, '2023-07-27 10:22:14', '2023-07-27 10:22:14'),
(20, 'LOJA', 1, 1, 16, 16, 15, '2023-07-27 10:22:20', '2023-07-27 10:22:20'),
(21, 'LOJA', 1, 1, 17, 17, 16, '2023-07-27 10:22:28', '2023-07-27 10:22:28'),
(22, 'LOJA', 1, 1, 17, 18, 18, '2023-07-27 10:22:41', '2023-07-27 10:22:41'),
(23, 'LOJA', 1, 1, 17, 17, 17, '2023-07-27 10:22:57', '2023-07-27 10:22:57'),
(24, 'LOJA', 1, 1, 18, 19, 19, '2023-07-27 10:23:05', '2023-07-27 10:23:05'),
(25, 'LOJA', 1, 1, 20, 20, 20, '2023-07-27 10:23:11', '2023-07-27 10:23:11'),
(26, 'LOJA', 1, 1, 21, 21, 21, '2023-07-27 10:23:17', '2023-07-27 10:27:05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `distritos`
--

CREATE TABLE `distritos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_distrito` varchar(255) NOT NULL,
  `codigo_distrito` varchar(255) NOT NULL,
  `numero_distrito` varchar(255) NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `distritos`
--

INSERT INTO `distritos` (`id`, `nombre_distrito`, `codigo_distrito`, `numero_distrito`, `id_usuario`, `created_at`, `updated_at`) VALUES
(1, 'LOJA', '11D01', '22', 1, '2023-07-24 09:35:35', '2023-07-28 23:41:03'),
(2, 'CATAMAYO', '11D02', '9', 1, '2023-07-24 09:36:08', '2023-07-24 09:36:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimientos`
--

CREATE TABLE `mantenimientos` (
  `id` int(10) UNSIGNED NOT NULL,
  `asunto` varchar(255) DEFAULT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `prevencion` varchar(255) DEFAULT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_vehiculos` int(10) UNSIGNED DEFAULT NULL,
  `id_personals` int(10) UNSIGNED DEFAULT NULL,
  `id_tipomantenimentos` int(10) UNSIGNED DEFAULT NULL,
  `id_solicitudmanteniminetos` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `mantenimientos`
--

INSERT INTO `mantenimientos` (`id`, `asunto`, `detalle`, `prevencion`, `id_usuario`, `id_vehiculos`, `id_personals`, `id_tipomantenimentos`, `id_solicitudmanteniminetos`, `created_at`, `updated_at`) VALUES
(1, 'Este carro entro por un mantenimiento preventivo', 'limpieza de filtros y cambio de aceite', 'Realizar esta actividad de forma regular segun el tiemp de cambio', 1, 1, 3, 1, 1, '2023-09-10 11:29:00', '2023-09-10 11:29:00'),
(2, 'carro mal', 'cambiar filtro', 'hacerlo seguido', 1, 3, 2, 4, 1, '2023-09-10 22:56:03', '2023-09-10 22:56:03'),
(3, 'Este carro entro por un mantenimiento preventivo', 'limpieza de filtros y cambio de ace', 'Realizar esta actividad de forma regular segun el tiemp de cambio', 1, 1, 6, 1, 5, '2023-09-11 09:02:26', '2023-09-11 09:02:26'),
(4, 'Este carro entro por un mantenimiento preventivo', 'limpieza de filtros y cambio de aceite', 'Realizar esta actividad de forma regular segun el tiemp de cambio', 1, 1, 3, 3, 1, '2023-09-12 10:11:07', '2023-09-22 09:51:28'),
(5, 'Limpieza de chasis, mantenimieno 1', 'limpieza de filtros y cambio de aceite,tambien se le cambio una llanta', 're recomienda traer después e dos meses para cambio completo de llantas', 1, 1, 4, 1, 7, '2023-09-22 09:41:35', '2023-09-22 09:50:41'),
(6, 'Cambiar filtro', 'en proceso', 'en proceso', 1, 4, 2, 4, 8, '2023-09-22 10:05:29', '2023-09-22 10:05:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2019_12_14_000001_create_roles_table', 1),
(6, '2023_06_10_224805_create_modulos_table', 1),
(7, '2023_06_10_224805_create_usuarios_table', 1),
(8, '2023_07_20_014931_create_distritos_table', 1),
(9, '2023_07_20_014955_create_parroquias_table', 1),
(10, '2023_07_20_015020_create_circuitos_table', 1),
(11, '2023_07_20_015036_create_subcircuitos_table', 1),
(13, '2023_07_20_020127_create_reportes_table', 1),
(14, '2023_07_20_020026_create_dependencias_table', 2),
(16, '2023_07_27_060401_create_vehiculos_table', 3),
(18, '2023_07_28_020252_create_personals_table', 4),
(19, '2023_07_28_042733_create_tipomantenimentos_table', 5),
(22, '2023_07_28_044604_create_solicitudmanteniminetos_table', 6),
(23, '2023_09_03_231153_create_mantenimientos_table', 6),
(24, '2023_09_21_033019_create_danosfrecuentes_table', 7),
(25, '2023_09_22_031038_create_revisiones_table', 8),
(26, '2023_09_22_140339_create_ordenmovilizaciones_table', 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_modulos` varchar(255) NOT NULL,
  `id_roles` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ruta` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `modulos`
--

INSERT INTO `modulos` (`id`, `nombre_modulos`, `id_roles`, `created_at`, `updated_at`, `ruta`) VALUES
(1, 'USUARIOS', 1, '2023-07-23 16:55:52', '2023-07-25 06:54:24', 'usuarios.index'),
(2, 'DISTRITOS', 1, '2023-07-23 16:56:32', '2023-07-25 06:54:09', 'distritos.index'),
(3, 'PARROQUIAS', 1, '2023-07-23 16:57:30', '2023-07-25 06:53:56', 'parroquias.index'),
(4, 'MODULOS', 1, '2023-07-24 03:10:07', '2023-07-25 06:53:42', 'modulos.index'),
(5, 'ROLES', 1, '2023-07-24 09:26:58', '2023-07-25 06:53:09', 'roles.index'),
(6, 'CIRCUITOS', 1, '2023-07-25 06:39:53', '2023-07-25 06:52:58', 'circuitos.index'),
(7, 'SUBCIRCUITOS', 1, '2023-07-25 06:44:00', '2023-07-25 06:52:48', 'subcircuitos.index'),
(8, 'DEPENDENCIAS', 1, '2023-07-25 06:44:42', '2023-07-25 06:51:50', 'dependencias.index'),
(9, 'REPORTES ATC', 1, '2023-07-25 06:45:00', '2023-07-25 06:52:05', 'reporte_eventos.index'),
(10, 'VEHICULOS', 1, '2023-07-25 06:45:18', '2023-07-25 06:50:55', 'vehiculos.index'),
(12, 'MODULOS', 2, '2023-07-25 06:55:50', '2023-07-25 06:55:50', 'modulos.index'),
(13, 'ROLES', 2, '2023-07-25 06:56:11', '2023-07-25 06:56:11', 'roles.index'),
(14, 'USUARIOS', 2, '2023-07-25 06:56:30', '2023-07-25 06:58:08', 'usuarios.index'),
(15, 'REPORTES ATC', 3, '2023-07-25 06:59:17', '2023-07-25 06:59:17', 'reporte_eventos.index'),
(17, 'DEPENDENCIAS', 3, '2023-07-25 07:00:25', '2023-07-25 07:00:25', 'dependencias.index'),
(18, 'SOLICITUD MANTENIMIENTO', 4, '2023-07-25 07:00:39', '2023-07-31 18:18:10', 'solicitudmantenimiento.index'),
(20, 'DEPENDENCIAS', 4, '2023-07-25 07:01:12', '2023-07-31 18:34:06', 'dependencias.index'),
(22, 'PERSONAL POLICIAL', 1, '2023-07-28 08:13:44', '2023-07-28 08:13:44', 'personals.index'),
(24, 'SOLICITUD MANTENIMIENTO', 1, '2023-07-28 10:39:14', '2023-07-28 10:39:14', 'solicitudmantenimiento.index'),
(36, 'ORDEN DE MANTENIMIENTO', 1, '2023-09-10 11:26:19', '2023-09-10 11:26:19', 'mantenimiento.index'),
(37, 'SOLICITUD MANTENIMIENTO', 6, '2023-09-11 08:57:53', '2023-09-11 08:57:53', 'solicitudmantenimiento.index'),
(38, 'VEHICULOS', 6, '2023-09-12 08:27:59', '2023-09-12 08:27:59', 'vehiculos.index'),
(39, 'USUARIOS', 6, '2023-09-12 08:54:29', '2023-09-12 08:54:29', 'usuarios.index'),
(48, 'ROLES', 2, '2023-09-21 07:51:50', '2023-09-21 07:51:50', 'roles.index'),
(49, 'USUARIOS', 2, '2023-09-21 07:51:58', '2023-09-21 07:51:58', 'usuarios.index'),
(50, 'DISTRITOS', 2, '2023-09-21 07:52:08', '2023-09-21 07:52:08', 'distritos.index'),
(51, 'PARROQUIAS', 2, '2023-09-21 07:52:24', '2023-09-21 07:52:24', 'parroquias.index'),
(52, 'CIRCUITOS', 2, '2023-09-21 07:52:31', '2023-09-21 07:52:31', 'circuitos.index'),
(53, 'SUBCIRCUITOS', 2, '2023-09-21 07:52:54', '2023-09-21 07:52:54', 'subcircuitos.index'),
(54, 'DEPENDENCIAS', 2, '2023-09-21 07:53:00', '2023-09-21 07:53:00', 'dependencias.index'),
(55, 'REPORTES ATC', 2, '2023-09-21 07:53:06', '2023-09-21 07:53:06', 'reporte_eventos.index'),
(56, 'VEHICULOS', 2, '2023-09-21 07:53:16', '2023-09-21 07:53:16', 'vehiculos.index'),
(58, 'SOLICITUD MANTENIMIENTO', 2, '2023-09-21 07:53:26', '2023-09-21 07:53:26', 'solicitudmantenimiento.index'),
(59, 'ORDEN DE MANTENIMIENTO', 2, '2023-09-21 07:53:35', '2023-09-21 07:53:35', 'mantenimiento.index'),
(62, 'ORDEN DE MOVILIZACION', 1, '2023-09-22 19:31:19', '2023-09-22 19:31:19', 'ordenmovilizacion.index'),
(64, 'ORDEN DE MOVILIZACION', 6, '2023-09-22 20:57:38', '2023-09-22 20:57:38', 'ordenmovilizacion.index'),
(68, 'ORDEN DE MOVILIZACION', 3, '2023-09-22 21:37:28', '2023-09-22 21:37:28', 'ordenmovilizacion.index'),
(69, 'SOLICITUD MANTENIMIENTO', 3, '2023-09-22 21:37:35', '2023-09-22 21:37:35', 'solicitudmantenimiento.index'),
(70, 'VEHICULOS', 3, '2023-09-22 21:37:48', '2023-09-22 21:37:48', 'vehiculos.index');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenmovilizaciones`
--

CREATE TABLE `ordenmovilizaciones` (
  `id` int(10) UNSIGNED NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `ruta` varchar(255) DEFAULT NULL,
  `km_inicial` varchar(255) DEFAULT NULL,
  `dato_ocupantes` varchar(255) DEFAULT NULL,
  `id_personals_conductor` int(10) UNSIGNED DEFAULT NULL,
  `id_personals_solicitante` int(10) UNSIGNED DEFAULT NULL,
  `id_dependencia` int(10) UNSIGNED DEFAULT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_vehiculos` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ordenmovilizaciones`
--

INSERT INTO `ordenmovilizaciones` (`id`, `motivo`, `ruta`, `km_inicial`, `dato_ocupantes`, `id_personals_conductor`, `id_personals_solicitante`, `id_dependencia`, `id_usuario`, `id_vehiculos`, `created_at`, `updated_at`) VALUES
(1, 'Salir a patrullar3', 'El mercado munincipla', '200km', 'EL SARGNETO PEDRO Y EL CORONEL CASTILLO', 3, 3, 24, 1, 1, '2023-09-22 20:15:04', '2023-09-22 20:35:43'),
(2, 'Salir a patrullar7', 'El mercado munincipla7', '2007km', 'EL SARGNETO PEDRO Y EL CORONEL CASTILLO777', 6, 7, 22, 1, 2, '2023-09-22 20:36:17', '2023-09-22 20:36:17'),
(4, 'Cumplir con la ronda normal', 'El parque central', '2007km', 'EL SARGNETO PEDRO Y EL CORONEL CASTILLO', 10, 7, 4, 10, 2, '2023-09-22 21:14:36', '2023-09-22 21:14:36'),
(5, 'Salir a patruyah', 'El mercado munincipla', '200km', 'EL SARGNETO PEDRO Y EL CORONEL CASTILLO', 6, 9, 18, 10, 3, '2023-09-22 21:26:04', '2023-09-22 21:26:40'),
(6, 'hhjfj', 'fjhjfgj', 'fjdjdfj', 'fj', 2, 2, 4, 5, 1, '2023-09-22 21:38:10', '2023-09-22 21:38:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parroquias`
--

CREATE TABLE `parroquias` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_parroquia` varchar(255) NOT NULL,
  `id_distrito` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `parroquias`
--

INSERT INTO `parroquias` (`id`, `nombre_parroquia`, `id_distrito`, `id_usuario`, `created_at`, `updated_at`) VALUES
(1, 'VILCABAMBA (VICTORIA)', 1, 1, '2023-07-25 07:24:38', '2023-07-25 07:24:38'),
(2, 'QUINARA', 1, 1, '2023-07-25 07:24:50', '2023-07-25 07:24:50'),
(3, 'MALACATOS (VALLADOLID)', 1, 1, '2023-07-25 07:25:02', '2023-07-25 07:25:02'),
(4, 'CHUQUIRIBAMBA', 1, 1, '2023-07-25 07:25:10', '2023-07-25 07:25:10'),
(5, 'TAQUIL (MIGUEL RIOFRIO)', 1, 1, '2023-07-25 07:25:18', '2023-07-25 07:25:18'),
(6, 'LOJA', 1, 1, '2023-07-25 07:25:26', '2023-07-25 07:25:26'),
(16, 'EL TAMBO', 2, 1, '2023-07-27 09:44:54', '2023-07-27 09:44:54'),
(17, 'CATAMAYO (LA TOMA)', 2, 1, '2023-07-27 09:45:10', '2023-07-27 09:45:10'),
(18, 'ZAMBI', 2, 1, '2023-07-27 09:45:22', '2023-07-27 09:45:22'),
(20, 'SAN PEDRO DE LA BENDITA', 2, 1, '2023-07-27 09:45:42', '2023-07-27 09:45:42'),
(21, 'CHAGUARPAMBA', 2, 1, '2023-07-27 09:45:49', '2023-07-27 09:45:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personals`
--

CREATE TABLE `personals` (
  `id` int(10) UNSIGNED NOT NULL,
  `identificacion` varchar(255) NOT NULL,
  `nombre_apellido` varchar(255) NOT NULL,
  `fecha_nacimiento` varchar(255) NOT NULL,
  `tipo_sangre` varchar(255) NOT NULL,
  `ciudad_nacimeinto` varchar(255) NOT NULL,
  `num_telefono` varchar(255) NOT NULL,
  `rango` varchar(255) NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_dependencia` int(10) UNSIGNED NOT NULL,
  `id_vehiculos` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `personals`
--

INSERT INTO `personals` (`id`, `identificacion`, `nombre_apellido`, `fecha_nacimiento`, `tipo_sangre`, `ciudad_nacimeinto`, `num_telefono`, `rango`, `id_usuario`, `id_dependencia`, `id_vehiculos`, `created_at`, `updated_at`) VALUES
(2, '0850401204', 'Raul MIna', '1999-01-27', 'O-', 'San Lorenzo', '0986342190', 'Subteniente', 1, 13, 2, '2023-07-28 09:12:25', '2023-07-28 09:12:25'),
(3, '098234781', 'Pedro Quiñonez', '1998-06-27', 'A+', 'San Lorenzo', '0987253674', 'Capitán', 1, 13, 2, '2023-07-28 09:17:24', '2023-07-28 09:17:24'),
(4, '1003286265', 'REYES', '2014-06-28', 'B-', 'QUITO', '55555555555', 'Sargento Segundo', 1, 20, 2, '2023-07-29 00:50:34', '2023-07-29 00:50:34'),
(6, '0800911778', 'MARIA B', '2023-06-30', 'AB+', 'QUITO', '55555555555', 'Teniente', 1, 12, 3, '2023-07-31 18:42:14', '2023-07-31 18:42:14'),
(7, '0850301110', 'Polk Vernaza', '1988-07-07', 'A-', 'San Lorenzo', '+593994516413', 'Capitán', 1, 26, 1, '2023-09-21 07:56:51', '2023-09-21 07:56:51'),
(9, '0850301111', 'Joel Gomez', '2023-09-06', 'A+', 'San Lorenzo', '+593994516413', 'Capitán', 1, 26, 1, '2023-09-21 07:57:29', '2023-09-21 07:57:29'),
(10, '0850301115', 'Darwin Ramirez', '2023-09-16', 'B+', 'San Lorenzo', '+593994516413', 'Capitán', 1, 6, 3, '2023-09-22 10:00:51', '2023-09-22 10:00:51');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `apellidos` varchar(255) NOT NULL,
  `nombres` varchar(255) NOT NULL,
  `contacto` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) NOT NULL,
  `detalle` varchar(255) NOT NULL,
  `id_circuito` int(10) UNSIGNED NOT NULL,
  `id_subcircuito` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `reportes`
--

INSERT INTO `reportes` (`id`, `apellidos`, `nombres`, `contacto`, `tipo`, `detalle`, `id_circuito`, `id_subcircuito`, `created_at`, `updated_at`) VALUES
(1, 'Quintero Paredes', 'Jose Pedro', 'jose@gmail.com', 'Reclamo', 'Seria bueno que no tarden mucho en llegar a los eventos.', 7, 8, '2023-07-27 10:31:32', '2023-07-27 10:31:32'),
(2, 'Quintero Paredes2', 'Jose Luis2', 'josePolk@gmail.com', 'Sugerencia', 'Mejorar la atención al usuario', 9, 10, '2023-07-27 10:33:09', '2023-07-27 10:33:09'),
(3, 'Quintero Paredes', 'Jose Luis', 'jose2@gmail.com', 'Reclamo', 'Seria bueno que no tarden mucho en llegar a los eventos.22', 1, 1, '2023-07-28 17:24:15', '2023-07-28 17:24:15'),
(4, 'Quintero Paredes', 'Jose Luis2', 'jose2@gmail.com', 'Sugerencia', 'Seria bueno que no tarden mucho en llegar a los eventos.', 1, 1, '2023-07-28 23:35:25', '2023-07-28 23:35:25'),
(5, 'Quintero Paredes', 'Jose Luis', 'jose2@gmail.com', 'Reclamo', 'falta de ..', 3, 3, '2023-07-29 01:35:14', '2023-07-29 01:35:14'),
(6, 'Quintero Paredes', 'Jose Pedro', 'josePolk@gmail.com', 'Reclamo', 'Seria bueno que no tarden mucho en llegar a los eventos.', 17, 17, '2023-07-31 08:52:58', '2023-07-31 08:52:58'),
(7, 'Quintero Paredes', 'Jose Pedro', 'josePolk@gmail.com', 'Reclamo', 'Seria bueno que no tarden mucho en llegar a los eventos.', 17, 17, '2023-07-31 08:52:58', '2023-07-31 08:52:58'),
(8, 'QUIÑONEZ GUERRERO', 'VICTOR HUGO', '0986521001', 'Sugerencia', 'Mejor la atención al cliente', 2, 2, '2023-09-12 08:18:13', '2023-09-12 08:18:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revisiones`
--

CREATE TABLE `revisiones` (
  `id` int(10) UNSIGNED NOT NULL,
  `pago_matricula` varchar(255) DEFAULT NULL,
  `págo_rodaje` varchar(255) DEFAULT NULL,
  `no_deuda_gad` varchar(255) DEFAULT NULL,
  `copia_cedula` varchar(255) DEFAULT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `recomendaciones` varchar(255) DEFAULT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_vehiculos` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `revisiones`
--

INSERT INTO `revisiones` (`id`, `pago_matricula`, `págo_rodaje`, `no_deuda_gad`, `copia_cedula`, `detalle`, `recomendaciones`, `id_usuario`, `id_vehiculos`, `created_at`, `updated_at`) VALUES
(1, 'SI', 'SI', 'SI', '', NULL, 'ERERWR', 1, 1, '2023-09-22 09:28:51', '2023-09-22 09:28:51'),
(2, 'SI', 'SI', 'SI', 'public/file/raul.mina@gmail.com/20230922/rtf/650d187290608.rtf', NULL, 'ERERWR', 1, 1, '2023-09-22 09:30:42', '2023-09-22 09:30:42'),
(3, 'sfd', 'd', 'd', 'public/file/raul.mina@gmail.com/20230922/docx/650d18b38e282.docx', NULL, 'ERERWR', 1, 1, '2023-09-22 09:31:47', '2023-09-22 09:31:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_rol` varchar(255) NOT NULL,
  `codigo_rol` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre_rol`, `codigo_rol`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 3, '2023-07-23 16:46:30', '2023-07-23 16:46:30'),
(2, 'Alta Gerencia', 2, '2023-07-23 16:46:30', '2023-07-23 16:46:30'),
(3, 'Técnico1', 1, '2023-07-23 16:48:29', '2023-07-23 16:48:29'),
(4, 'Técnico2', 0, '2023-07-23 16:48:29', '2023-07-23 16:48:29'),
(6, 'Usuario', 5, '2023-07-31 08:56:53', '2023-07-31 08:56:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudmanteniminetos`
--

CREATE TABLE `solicitudmanteniminetos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_apellido` varchar(255) NOT NULL,
  `num_telefono` varchar(255) NOT NULL,
  `detalle` varchar(255) NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_vehiculos` int(10) UNSIGNED DEFAULT NULL,
  `id_tipomantenimentos` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `identificacion` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `solicitudmanteniminetos`
--

INSERT INTO `solicitudmanteniminetos` (`id`, `nombre_apellido`, `num_telefono`, `detalle`, `id_usuario`, `id_vehiculos`, `id_tipomantenimentos`, `created_at`, `updated_at`, `identificacion`) VALUES
(1, 'POLK BRANDO VERNAZA QUIÑONEZ', '0981170551', 'limpieza de filtros y cambio de aceite', 1, 3, 3, '2023-09-10 11:28:04', '2023-09-11 08:34:47', '0850301110'),
(4, 'Pedro Jose Mina Quiñonez', '0981170551', 'limpieza de filtros y cambio de ace', 1, 2, 4, '2023-09-11 08:35:14', '2023-09-11 08:35:14', '0850301110'),
(5, 'Pablo Eduardo Quiñonez Valencia', '0981445510', 'cambiar filtro', 9, 1, 1, '2023-09-11 09:00:03', '2023-09-11 09:00:03', '0850301112'),
(6, 'Joel Gomez', '0981170551', 'limpieza de filtros y cambio de aceite', 10, 4, 4, '2023-09-21 08:02:23', '2023-09-21 08:02:23', '0850301112'),
(7, 'POLK BRANDO VERNAZA QUIÑONEZ', '0981170551', 'limpieza de filtros y cambio de aceite', 10, 1, 1, '2023-09-21 08:08:09', '2023-09-21 08:08:09', '0850301110'),
(8, 'Raul  Mina', '0981445510', 'Cambiar filtro', 10, 4, 4, '2023-09-22 10:02:15', '2023-09-22 10:02:15', '0850301114');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcircuitos`
--

CREATE TABLE `subcircuitos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_subcircuito` varchar(255) NOT NULL,
  `codigo_subcircuito` varchar(255) NOT NULL,
  `numero_subcircuito` varchar(255) NOT NULL,
  `id_circuito` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `subcircuitos`
--

INSERT INTO `subcircuitos` (`id`, `nombre_subcircuito`, `codigo_subcircuito`, `numero_subcircuito`, `id_circuito`, `id_usuario`, `created_at`, `updated_at`) VALUES
(1, 'VILCABAMBA 1', '11D01C01S01', '1', 1, 1, '2023-07-25 07:45:07', '2023-07-25 07:45:07'),
(2, 'YANGANA 1', '11D01C02S01', '1', 2, 1, '2023-07-25 07:45:28', '2023-07-25 07:45:28'),
(3, 'MALACATOS 1', '11D01C03S01', '1', 3, 1, '2023-07-25 07:45:57', '2023-07-25 07:45:57'),
(4, 'TAQUIL 1', '11D01C04S01', '2', 4, 1, '2023-07-27 10:09:19', '2023-07-27 10:09:19'),
(5, 'TAQUIL 2', '11D01C04S02', '2', 5, 1, '2023-07-27 10:09:41', '2023-07-27 10:09:41'),
(6, 'ZAMORA HUAYCO 1', '1D01C05S01', '1', 6, 1, '2023-07-27 10:10:08', '2023-07-27 10:10:08'),
(7, 'ESTEBAN GODOY 1', '11D01C06S02', '2', 7, 1, '2023-07-27 10:10:26', '2023-07-27 10:10:26'),
(8, 'ESTEBAN GODOY 2', '11D01C06S02', '2', 7, 1, '2023-07-27 10:10:54', '2023-07-27 10:10:54'),
(9, 'EL PARAISO 1', '11D01C07S01', '1', 8, 1, '2023-07-27 10:11:16', '2023-07-27 10:11:16'),
(10, 'CELI ROMAN 1', '11D01C08S01', '1', 9, 1, '2023-07-27 10:12:11', '2023-07-27 10:12:11'),
(11, 'IV CENTENARIO 1', '11D01C09S01', '1', 10, 1, '2023-07-27 10:12:36', '2023-07-27 10:12:36'),
(12, 'TEBAIDA 1', '11D01C10S01', '1', 11, 1, '2023-07-27 10:12:55', '2023-07-27 10:12:55'),
(13, 'LOS MOLINOS 1', '11D01C11S01', '1', 12, 1, '2023-07-27 10:13:15', '2023-07-27 10:13:15'),
(14, 'CHONTACRUZ 1', '11D01C12S01', '2', 13, 1, '2023-07-27 10:13:35', '2023-07-27 10:13:35'),
(15, 'EL TAMBO 1', '11D02C01S01', '1', 16, 1, '2023-07-27 10:17:10', '2023-07-27 10:17:10'),
(16, 'CATAMAYO NORTE 1', '11D02C02S01', '2', 17, 1, '2023-07-27 10:17:28', '2023-07-27 10:17:40'),
(17, 'CATAMAYO NORTE 2', '11D02C02S02', '2', 17, 1, '2023-07-27 10:18:01', '2023-07-27 10:18:01'),
(18, 'CATAMAYO SAN JOSE 1', '11D02C03S01', '1', 18, 1, '2023-07-27 10:18:21', '2023-07-27 10:18:21'),
(19, 'GUAYQUICHUMA 1', '11D02C04S01', '1', 19, 1, '2023-07-27 10:18:39', '2023-07-27 10:18:39'),
(20, 'SAN PEDRO DE LA BENDITA 1', '11D02C05S01', '1', 20, 1, '2023-07-27 10:18:54', '2023-07-27 10:18:54'),
(21, 'CHAGUARPAMBA 1', '11D02C06S01', '1', 21, 1, '2023-07-27 10:19:10', '2023-07-27 10:19:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipomantenimentos`
--

CREATE TABLE `tipomantenimentos` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipo_mantenineto` varchar(255) NOT NULL,
  `detalle` varchar(255) NOT NULL,
  `precio` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tipomantenimentos`
--

INSERT INTO `tipomantenimentos` (`id`, `tipo_mantenineto`, `detalle`, `precio`, `created_at`, `updated_at`) VALUES
(1, 'Mantenimiento 1', 'El mantenimiento 1 corresponde a cambio de aceite, revisión y cambio de pastillas, líquido de frenos y filtro de combustible. El costo total por mantenimiento 1 es $43.59 incluye la mano de obra.', 43.59, '2023-07-28 04:40:01', '2023-07-28 04:40:01'),
(3, 'Mantenimiento 2', 'El mantenimiento 2 corresponde a un mantenimiento 1 más cambio de filtro de aire cuando son vehículos, cambio del líquido refrigerante y cambio de luces delanteras y posteriores', 60.00, '2023-07-28 04:42:16', '2023-07-28 04:42:16'),
(4, 'Mantenimiento 3', '. Cuando son motocicletas se excluye el filtro de aire y su costo se resta $15. El mantenimiento 3 corresponde a cambio de batería y ajustes en el sistema eléctrico y tiene un costo de $180', 180.00, '2023-07-28 04:43:32', '2023-07-28 04:43:32'),
(5, ' Motocicletas ', 'Cuando son motocicletas se excluye el filtro de aire y su costo se resta $15.', 15.00, '2023-07-28 05:00:35', '2023-07-28 05:00:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre_apellido` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `id_roles` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_apellido`, `correo`, `clave`, `usuario`, `id_roles`, `created_at`, `updated_at`) VALUES
(1, 'Raul MIna', 'raul.mina@gmail.com', '$2y$10$Mb4cpqCOgyJQAHE.rGzj8.2z4OqvHaNhkXRsbXQRDzGuzWUKYeXcO', 'Raul', 1, '2023-07-23 21:49:21', '2023-07-24 09:15:36'),
(5, 'Polk vernaza', 'polk12@gmail.com', '$2y$10$mJB/Qr7T56DnUX340hZy7uxXrB/M8JlztJ6C5QB1q/J3hGvQSvcUS', 'Polk', 3, '2023-07-27 09:43:22', '2023-07-29 01:03:47'),
(6, 'Pedro Quiñonez', 'pedro2@gmail.com', '$2y$10$nSQGa6LUGce/om0vxzXxHeWTcbRMkve2g7G80nihldbexv8o8s1.y', 'Raul', 6, '2023-07-28 11:37:21', '2023-07-31 08:58:40'),
(7, 'Maria Catillo', 'mariacastillo@gmail.com', '$2y$10$/AXYYCRrsBtzF5yBqH5qLOC9gTqfEjmsYXG.JSyj2.h01fL9AB6Qa', 'Maria Casti', 4, '2023-07-29 02:52:00', '2023-07-31 18:03:15'),
(8, 'Diana Alexandra', 'dianaalexandra@gmail.com', '$2y$10$T10OHwbnxxJ6OPflauf.ue7w0pHYr2gY05rHHNZqYoGswGSCs53ZC', 'dianaA', 3, '2023-07-31 18:36:38', '2023-07-31 18:36:38'),
(9, 'Pablo Eduardo Quiñonez Valencia', 'pablo@gmail.com', '$2y$10$DKAYvxkolDatSjSfWD1us.vJRguzt/y4XK5Pe/f/LQZGcSXTiC5h6', 'Pablo', 6, '2023-09-11 08:56:59', '2023-09-11 08:56:59'),
(10, 'Joel Gomez Ovando', 'joelov@gmail.com', '$2y$10$CdJ3lXpvFyN9zKiY6SeUguWq.gST2Zm4GWPOH64o956hlRa3Jr9Je', 'joelov54', 6, '2023-09-12 08:26:47', '2023-09-12 09:18:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipo_vehiculo` varchar(255) NOT NULL,
  `placa` varchar(255) NOT NULL,
  `chasis` varchar(255) NOT NULL,
  `marca` varchar(255) NOT NULL,
  `modelo` varchar(255) NOT NULL,
  `motor` varchar(255) NOT NULL,
  `kilometraje` varchar(255) NOT NULL,
  `cilindraje` varchar(255) NOT NULL,
  `capacidad_carga` varchar(255) NOT NULL,
  `capacidad_pasajeros` varchar(255) NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `id_dependencia` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`id`, `tipo_vehiculo`, `placa`, `chasis`, `marca`, `modelo`, `motor`, `kilometraje`, `cilindraje`, `capacidad_carga`, `capacidad_pasajeros`, `id_usuario`, `id_dependencia`, `created_at`, `updated_at`) VALUES
(1, 'Camioneta', 'SP25555', 'hrt3456', 'Mazda', 'BT-50', 'A GASOLINA 2.2', '20000', '45', '40KG', '6', 1, 9, '2023-07-27 11:42:58', '2023-09-12 10:06:48'),
(2, 'Camionesta', 'SP2568', 'hrt34567', 'Mazda', 'BT-50', 'A GASOLINA 2.2', '6666554', '45', '40KG', '6', 1, 24, '2023-07-27 12:04:19', '2023-07-28 06:20:41'),
(3, 'CARRO', 'HR989', 'HR452', 'CHEVROLET', 'SAIL', 'A GASOLINA', '90.000', '45', '40KG', '4', 1, 15, '2023-07-29 00:53:31', '2023-09-11 08:21:34'),
(4, 'Camionesta', 'SP2567', 'hrt34566r6', 'Masda6', 'BT-50', 'A GASOLINA 2.2', '20000', '45', '40KG', '5', 8, 19, '2023-07-31 18:39:47', '2023-07-31 18:39:47'),
(5, 'Camioneta', 'SP2067', '236478', 'MAZDA', 'BT50', '2.2 GASOLINA', '90.000', '3.5', '500KG', '8', 10, 20, '2023-09-12 09:05:18', '2023-09-12 09:05:18');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `circuitos`
--
ALTER TABLE `circuitos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `circuitos_id_parroquia_foreign` (`id_parroquia`),
  ADD KEY `circuitos_id_usuario_foreign` (`id_usuario`);

--
-- Indices de la tabla `danosfrecuentes`
--
ALTER TABLE `danosfrecuentes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `danosfrecuentes_id_usuario_foreign` (`id_usuario`),
  ADD KEY `danosfrecuentes_id_vehiculos_foreign` (`id_vehiculos`);

--
-- Indices de la tabla `dependencias`
--
ALTER TABLE `dependencias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dependencias_id_usuario_foreign` (`id_usuario`),
  ADD KEY `dependencias_id_distrito_foreign` (`id_distrito`),
  ADD KEY `dependencias_id_parroquia_foreign` (`id_parroquia`),
  ADD KEY `dependencias_id_circuito_foreign` (`id_circuito`),
  ADD KEY `dependencias_id_subcircuito_foreign` (`id_subcircuito`);

--
-- Indices de la tabla `distritos`
--
ALTER TABLE `distritos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `distritos_id_usuario_foreign` (`id_usuario`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mantenimientos_id_usuario_foreign` (`id_usuario`),
  ADD KEY `mantenimientos_id_vehiculos_foreign` (`id_vehiculos`),
  ADD KEY `mantenimientos_id_personals_foreign` (`id_personals`),
  ADD KEY `mantenimientos_id_tipomantenimentos_foreign` (`id_tipomantenimentos`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modulos_id_roles_foreign` (`id_roles`);

--
-- Indices de la tabla `ordenmovilizaciones`
--
ALTER TABLE `ordenmovilizaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ordenmovilizaciones_id_personals_conductor_foreign` (`id_personals_conductor`),
  ADD KEY `ordenmovilizaciones_id_personals_solicitante_foreign` (`id_personals_solicitante`),
  ADD KEY `ordenmovilizaciones_id_dependencia_foreign` (`id_dependencia`),
  ADD KEY `ordenmovilizaciones_id_usuario_foreign` (`id_usuario`),
  ADD KEY `ordenmovilizaciones_id_vehiculos_foreign` (`id_vehiculos`);

--
-- Indices de la tabla `parroquias`
--
ALTER TABLE `parroquias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parroquias_id_distrito_foreign` (`id_distrito`),
  ADD KEY `parroquias_id_usuario_foreign` (`id_usuario`);

--
-- Indices de la tabla `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `personals`
--
ALTER TABLE `personals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personals_identificacion_unique` (`identificacion`),
  ADD KEY `personals_id_usuario_foreign` (`id_usuario`),
  ADD KEY `personals_id_dependencia_foreign` (`id_dependencia`),
  ADD KEY `personals_id_vehiculos_foreign` (`id_vehiculos`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reportes_id_circuito_foreign` (`id_circuito`),
  ADD KEY `reportes_id_subcircuito_foreign` (`id_subcircuito`);

--
-- Indices de la tabla `revisiones`
--
ALTER TABLE `revisiones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `revisiones_id_usuario_foreign` (`id_usuario`),
  ADD KEY `revisiones_id_vehiculos_foreign` (`id_vehiculos`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `solicitudmanteniminetos`
--
ALTER TABLE `solicitudmanteniminetos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitudmanteniminetos_id_usuario_foreign` (`id_usuario`),
  ADD KEY `solicitudmanteniminetos_id_vehiculos_foreign` (`id_vehiculos`),
  ADD KEY `solicitudmanteniminetos_id_tipomantenimentos_foreign` (`id_tipomantenimentos`);

--
-- Indices de la tabla `subcircuitos`
--
ALTER TABLE `subcircuitos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcircuitos_id_circuito_foreign` (`id_circuito`),
  ADD KEY `subcircuitos_id_usuario_foreign` (`id_usuario`);

--
-- Indices de la tabla `tipomantenimentos`
--
ALTER TABLE `tipomantenimentos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuarios_correo_unique` (`correo`),
  ADD KEY `usuarios_id_roles_foreign` (`id_roles`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vehiculos_placa_unique` (`placa`),
  ADD UNIQUE KEY `vehiculos_chasis_unique` (`chasis`),
  ADD KEY `vehiculos_id_usuario_foreign` (`id_usuario`),
  ADD KEY `vehiculos_id_dependencia_foreign` (`id_dependencia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `circuitos`
--
ALTER TABLE `circuitos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `danosfrecuentes`
--
ALTER TABLE `danosfrecuentes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `dependencias`
--
ALTER TABLE `dependencias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `distritos`
--
ALTER TABLE `distritos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `modulos`
--
ALTER TABLE `modulos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT de la tabla `ordenmovilizaciones`
--
ALTER TABLE `ordenmovilizaciones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `parroquias`
--
ALTER TABLE `parroquias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `personals`
--
ALTER TABLE `personals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reportes`
--
ALTER TABLE `reportes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `revisiones`
--
ALTER TABLE `revisiones`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `solicitudmanteniminetos`
--
ALTER TABLE `solicitudmanteniminetos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `subcircuitos`
--
ALTER TABLE `subcircuitos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `tipomantenimentos`
--
ALTER TABLE `tipomantenimentos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `circuitos`
--
ALTER TABLE `circuitos`
  ADD CONSTRAINT `circuitos_id_parroquia_foreign` FOREIGN KEY (`id_parroquia`) REFERENCES `parroquias` (`id`),
  ADD CONSTRAINT `circuitos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `danosfrecuentes`
--
ALTER TABLE `danosfrecuentes`
  ADD CONSTRAINT `danosfrecuentes_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `danosfrecuentes_id_vehiculos_foreign` FOREIGN KEY (`id_vehiculos`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `dependencias`
--
ALTER TABLE `dependencias`
  ADD CONSTRAINT `dependencias_id_circuito_foreign` FOREIGN KEY (`id_circuito`) REFERENCES `circuitos` (`id`),
  ADD CONSTRAINT `dependencias_id_distrito_foreign` FOREIGN KEY (`id_distrito`) REFERENCES `distritos` (`id`),
  ADD CONSTRAINT `dependencias_id_parroquia_foreign` FOREIGN KEY (`id_parroquia`) REFERENCES `parroquias` (`id`),
  ADD CONSTRAINT `dependencias_id_subcircuito_foreign` FOREIGN KEY (`id_subcircuito`) REFERENCES `subcircuitos` (`id`),
  ADD CONSTRAINT `dependencias_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `distritos`
--
ALTER TABLE `distritos`
  ADD CONSTRAINT `distritos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  ADD CONSTRAINT `mantenimientos_id_personals_foreign` FOREIGN KEY (`id_personals`) REFERENCES `personals` (`id`),
  ADD CONSTRAINT `mantenimientos_id_tipomantenimentos_foreign` FOREIGN KEY (`id_tipomantenimentos`) REFERENCES `tipomantenimentos` (`id`),
  ADD CONSTRAINT `mantenimientos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `mantenimientos_id_vehiculos_foreign` FOREIGN KEY (`id_vehiculos`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD CONSTRAINT `modulos_id_roles_foreign` FOREIGN KEY (`id_roles`) REFERENCES `roles` (`id`);

--
-- Filtros para la tabla `ordenmovilizaciones`
--
ALTER TABLE `ordenmovilizaciones`
  ADD CONSTRAINT `ordenmovilizaciones_id_dependencia_foreign` FOREIGN KEY (`id_dependencia`) REFERENCES `dependencias` (`id`),
  ADD CONSTRAINT `ordenmovilizaciones_id_personals_conductor_foreign` FOREIGN KEY (`id_personals_conductor`) REFERENCES `personals` (`id`),
  ADD CONSTRAINT `ordenmovilizaciones_id_personals_solicitante_foreign` FOREIGN KEY (`id_personals_solicitante`) REFERENCES `personals` (`id`),
  ADD CONSTRAINT `ordenmovilizaciones_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `ordenmovilizaciones_id_vehiculos_foreign` FOREIGN KEY (`id_vehiculos`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `parroquias`
--
ALTER TABLE `parroquias`
  ADD CONSTRAINT `parroquias_id_distrito_foreign` FOREIGN KEY (`id_distrito`) REFERENCES `distritos` (`id`),
  ADD CONSTRAINT `parroquias_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `personals`
--
ALTER TABLE `personals`
  ADD CONSTRAINT `personals_id_dependencia_foreign` FOREIGN KEY (`id_dependencia`) REFERENCES `dependencias` (`id`),
  ADD CONSTRAINT `personals_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `personals_id_vehiculos_foreign` FOREIGN KEY (`id_vehiculos`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD CONSTRAINT `reportes_id_circuito_foreign` FOREIGN KEY (`id_circuito`) REFERENCES `circuitos` (`id`),
  ADD CONSTRAINT `reportes_id_subcircuito_foreign` FOREIGN KEY (`id_subcircuito`) REFERENCES `subcircuitos` (`id`);

--
-- Filtros para la tabla `revisiones`
--
ALTER TABLE `revisiones`
  ADD CONSTRAINT `revisiones_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `revisiones_id_vehiculos_foreign` FOREIGN KEY (`id_vehiculos`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `solicitudmanteniminetos`
--
ALTER TABLE `solicitudmanteniminetos`
  ADD CONSTRAINT `solicitudmanteniminetos_id_tipomantenimentos_foreign` FOREIGN KEY (`id_tipomantenimentos`) REFERENCES `tipomantenimentos` (`id`),
  ADD CONSTRAINT `solicitudmanteniminetos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `solicitudmanteniminetos_id_vehiculos_foreign` FOREIGN KEY (`id_vehiculos`) REFERENCES `vehiculos` (`id`);

--
-- Filtros para la tabla `subcircuitos`
--
ALTER TABLE `subcircuitos`
  ADD CONSTRAINT `subcircuitos_id_circuito_foreign` FOREIGN KEY (`id_circuito`) REFERENCES `circuitos` (`id`),
  ADD CONSTRAINT `subcircuitos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_id_roles_foreign` FOREIGN KEY (`id_roles`) REFERENCES `roles` (`id`);

--
-- Filtros para la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD CONSTRAINT `vehiculos_id_dependencia_foreign` FOREIGN KEY (`id_dependencia`) REFERENCES `dependencias` (`id`),
  ADD CONSTRAINT `vehiculos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
