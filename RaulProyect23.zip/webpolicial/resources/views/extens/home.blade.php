<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->
@extends('layouts.app')

<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
@section('title', 'POLICIA NACIONAL')

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
@section('content')
<div class="containe  page_style"">

<center>
<h1>HOME</h1>
<img class="logo_banner"src="img/LO1.png" alt="Image 2"><br>

</center>
</div>
@endsection
