<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'USUARIOS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h1>USUARIOS</h1>
<img class="logo_banner"src="../../img/LO1.png" alt="Image 2">
</center>
</div>
<br>
<form method="POST"  action="<?php echo e(route('buscarus')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="form-group">

        <input type="text" name="filtro_nombre" placeholder="Nombre"class="form-control" >
    </div>

    <!-- Agrega más campos de filtro según tus necesidades -->
    <button type="submit" class="btn btn-info">Buscar</button>
</form>
<?php if(session('roles')->codigo_rol== 3 ): ?>
<a href="<?php echo e(route('usuarios.create')); ?> " class="btn btn-primary">Crear Usuario</a>
<?php endif; ?>
<button onclick="imprimirDiv()" class="btn btn-success">Imprimir</button>

<?php if(session('roles')->codigo_rol>=0): ?>
<div class="container "id="reportid">
<table class="table boder_bar btn_modulos">
  <thead>
    <tr>
      <th>ID</th>
      <th>Nombre</th>
      <th>Correo</th>
      <th>Usuario</th>
      <th>Rol</th>
      <th>Editar</th>
      <?php if(session('roles')->codigo_rol== 3 ): ?>  <th>Eliminar</th><?php endif; ?>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($dato->id==session('user')->id || session('roles')->codigo_rol== 3 ): ?>
    <tr>
      <td><?php echo e($dato['id']); ?></td>
      <td><?php echo e($dato['nombre_apellido']); ?></td>
      <td><?php echo e($dato['correo']); ?></td>
      <td><?php echo e($dato['usuario']); ?></td>
      <td><?php echo e($dato->Role['nombre_rol']); ?>


      </td>
      <td><a  class="btn btn-primary" href="<?php echo e(route('usuarios.edit',$dato['id'])); ?>">Editar</a></td>

      <td>
        <form class="deleteForm" action="<?php echo e(route('usuarios.destroy',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <?php if(session('roles')->codigo_rol== 3 ): ?>   <button type="submit" class="btn btn-danger">Eliminar</button><?php endif; ?>
        </form>
     </td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php echo e($datos->links()); ?>

</div>

<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\webpolicial\resources\views/usuarios/index.blade.php ENDPATH**/ ?>