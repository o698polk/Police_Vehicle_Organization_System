<?php echo e($user); ?>

<?php /**PATH C:\xampp\htdocs\RaulPoryect\webpolicial\resources\views/prueba.blade.php ENDPATH**/ ?>