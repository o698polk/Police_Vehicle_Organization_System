<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'CREAR UNA SOLIICITUD'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>CREAR ORDEN DE MOVILIZACION </h1>
        <img class="logo_banner" src="../img/LO1.png" alt="Image 2">
    </center>


<div class="container">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('ordenmovilizacion.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="motivo">Motivo</label>
                                <input type="text" name="motivo" id="motivo" class="form-control" placeholder="" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="ruta">Ruta</label>
                                <input type="text" name="ruta" id="ruta" class="form-control" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="km_inicial">Kilometraje Inicial</label>
                                <input type="text" id="km_inicial" name="km_inicial" class="form-control" required>
                            </div>
                        
                         <div class="form-group">
                                <label for="dato_ocupantes">Datos de los Ocupantes </label>
                                <input type="text" id="dato_ocupantesl" name="dato_ocupantes" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="id_vehiculos">Selecciona el Vehiculo:</label>
                                <select class="form-control" id="id_vehiculos" name="id_vehiculos">
                                    <?php $__currentLoopData = $datos['Vehiculo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->tipo_vehiculo); ?>-<?php echo e($dato->placa); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="id_personals_conductor">Selecciona Conductor:</label>
                                <select class="form-control" id="id_personals_conductor" name="id_personals_conductor">
                                    <?php $__currentLoopData = $datos['Personal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->nombre_apellido); ?>/<?php echo e($dato->identificacion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                              <div class="form-group">
                                <label for="id_personals_solicitante">Selecciona Solicitante:</label>
                                <select class="form-control" id="id_personals_solicitante" name="id_personals_solicitante">
                                    <?php $__currentLoopData = $datos['Personal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->nombre_apellido); ?>/<?php echo e($dato->identificacion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="id_dependencia">Selecciona una Dependnecia</label>
                                <select class="form-control" id="id_dependencia" name="id_dependencia">
                                    <?php $__currentLoopData = $datos['Dependencia']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->id_subcircuito); ?>-<?php echo e($dato->provincia); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                           
                            <?php  $user = session('user') ?>
                            <div class="form-group">

                                <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo $user->__get('id');?>"required style="display: none;"readonly>
                            </div>

                            <button type="submit" class="btn btn-primary">Crear</button>
                        </form>
                        <a href="<?php echo e(route('ordenmovilizacion.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\webpolicial-examen\webpolicial\resources\views/ordenmovilizacion/create.blade.php ENDPATH**/ ?>