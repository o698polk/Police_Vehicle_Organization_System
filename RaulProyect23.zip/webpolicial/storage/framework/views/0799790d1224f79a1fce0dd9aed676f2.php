<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'CREAR MODULO'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>CREAR MODULO</h1>
        <img class="logo_banner" src="../img/LO1.png" alt="Image 2">
    </center>


<div class="container">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('modulos.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="nombre_modulos">Modulo</label>

                                <select class="form-control" name="nombre_modulos" id="nombre_modulos">
                                    <option value=""></option>
                                    <option value="ROLES">ROLES</option>
                                    <option value="USUARIOS">USUARIOS</option>
                                    <option value="DISTRITOS">DISTRITOS</option>
                                    <option value="PARROQUIAS">PARROQUIAS</option>
                                    <option value="CIRCUITOS">CIRCUITOS</option>
                                    <option value="SUBCIRCUITOS">SUBCIRCUITOS</option>
                                    <option value="DEPENDENCIAS">DEPENDENCIAS</option>
                                    <option value="REPORTES ATC">REPORTES ATC</option>
                                    <option value="VEHICULOS">VEHICULOS</option>
                                    <option value="PERSONAL POLICIAL">PERSONAL POLICIAL</option>
                                    <option value="SOLICITUD MANTENIMIENTO">SOLICITUD MANTENIMIENTO</option>
                                    <option value="ORDEN DE MANTENIMIENTO">ORDEN DE MANTENIMIENTO </option>
                                  <!--  <option value="REVISION">REVISION </option>-->
                                </select>
                            </div>

                            <div class="form-group"id="rutamodulo">
                                <select class="form-control" name="ruta" id="ruta">
                                </select>

                            </div>

                            <div class="form-group">
                                <label for="id_roles">Selecciona un Rol:</label>
                                <select class="form-control" id="id_roles" name="id_roles">
                                    <?php $__currentLoopData = $datos['Role']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->nombre_rol); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Crear</button>
                        </form>
                        <a href="<?php echo e(route('modulos.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\webpolicial\resources\views/modulos/create.blade.php ENDPATH**/ ?>