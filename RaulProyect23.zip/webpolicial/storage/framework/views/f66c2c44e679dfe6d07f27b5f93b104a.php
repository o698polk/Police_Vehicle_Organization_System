<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR SUBCIRCUITOS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h1>CIRCUITOS</h1>
<img class="logo_banner"src="../../img/LO1.png" alt="Image 2">
</center>
</div>

<?php if(session('roles')->codigo_rol>=0): ?>
<div class="container ">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                        <?php endif; ?>

                        <form method="post" action="<?php echo e(route('solicitudmantenimiento.update',$matriz['depen']->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                             <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($matriz['depen']->id); ?>">
                            <div class="form-group">
                                <label for="nombre_apellido">Nombres</label>
                                <input type="text" name="nombre_apellido" id="nombre_apellido" class="form-control"value="<?php echo e($matriz['depen']->nombre_apellido); ?>" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="identificacion">DNI</label>
                                <input type="text" name="identificacion" id="identificacion" class="form-control"value="<?php echo e($matriz['depen']->identificacion); ?>" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="num_telefono" >Numero de Telefono</label>
                                <input type="text" name="num_telefono" id="num_telefonoo" class="form-control" value="<?php echo e($matriz['depen']->num_telefono); ?>"required >
                            </div>
                            <div class="form-group">
                                <label for="detalle">Detalle</label>
                                <input type="text" id="detalle" name="detalle" class="form-control"  value="<?php echo e($matriz['depen']->detalle); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="id_circuito">Selecciona un Vehiculo:</label>
                                <select name="id_vehiculos" id="id_vehiculos" class="form-control">
                                    <?php $__currentLoopData = $matriz['datos']['Vehiculo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dato->id); ?>"
                                            <?php echo e($matriz['depen']->id_vehiculos== $dato->id ? 'selected' : ''); ?>>
                                            <?php echo e($dato->tipo_vehiculo); ?>/ <?php echo e($dato->placa); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="id_tipomantenimentos">Selecciona un Tipo de mantenimiento</label>
                                <select name="id_tipomantenimentos" id="id_tipomantenimentos" class="form-control">
                                    <?php $__currentLoopData = $matriz['datos']['Tipomantenimento']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dato->id); ?>"
                                            <?php echo e($matriz['depen']->id_tipomantenimentos== $dato->id ? 'selected' : ''); ?>>
                                            <?php echo e($dato->tipo_mantenineto); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php  $user = session('user') ?>
                            <div class="form-group">

                                <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo e($matriz['depen']->id_usuario); ?>"required style="display: none;"readonly>
                            </div>
                            <button type="submit" class="btn btn-primary">Actualizar</button>
                        </form>
                        <a href="<?php echo e(route('solicitudmantenimiento.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




  </tbody>
</table>

</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulProyect\webpolicial\resources\views/solicitudmantenimiento/edit.blade.php ENDPATH**/ ?>