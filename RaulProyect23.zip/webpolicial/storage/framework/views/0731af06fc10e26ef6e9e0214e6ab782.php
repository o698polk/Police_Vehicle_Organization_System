<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'DEPENDENCIA'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>DEPENDENCIA</h1>
        <img class="logo_banner" src="../../img/LO1.png" alt="Image 2">
    </center>
</div>
<br>
<form method="POST"  action="<?php echo e(route('buscarreport')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="form-group">


        <input type="text" name="filtro_nombre" placeholder="Nombre "class="form-control" >
    </div>


    <button type="submit" class="btn btn-info">Buscar</button>
</form>
<a href="<?php echo e(route('reporte_eventos.create')); ?> " class="btn btn-primary">Crear Reporte</a>
<button onclick="imprimirDiv()" class="btn btn-success">Imprimir Reporte</button>


<?php if(session('roles')->codigo_rol>=0): ?>
<div class="container ">

    <form action="<?php echo e(route('buscarrepfech')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="fecha_inicial">Fecha Inicial:</label>
        <input type="datetime-local"  name="fecha_inicial" id="fecha_inicial" value="<?php echo e(date('Y-m-d\TH:i:s', strtotime('2023-07-0 23:59:59'))); ?>">
        <label for="fecha_final">Fecha Final:</label>

        <input type="datetime-local" name="fecha_final" id="fecha_final" value="<?php echo e(date('Y-m-d\TH:i:s', strtotime('2023-07-31 23:59:59'))); ?>">

        <button type="submit" class="btn btn-secondary" >Mostrar Reporte</button>
    </form>
<div class="container pdfrepor" id="reportid">
    <table class="table boder_bar btn_modulos">
        <thead>
            <tr>
                <th>Fecha Nincial</th>
                <th>Fecha Final</th>
                <th>#</th>
                <th>Tipo</th>
                <th>Circuito</th>
                <th>Subcircuito</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($fechaInicial); ?></td>
                    <td><?php echo e($fechaFinal); ?></td>
                    <td><?php echo e($registro->total); ?></td>
                    <td><?php echo e($registro->tipo); ?></td>
                    <td><?php echo e($registro->Circuito->nombre_circuito); ?></td>
                    <td><?php echo e($registro->Subcircuito->nombre_subcircuito); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<a href="<?php echo e(route('reporte_eventos.index')); ?>" class="btn btn-defaul">Regresar</a>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\webpolicial\resources\views/reporte_eventos/reportes.blade.php ENDPATH**/ ?>