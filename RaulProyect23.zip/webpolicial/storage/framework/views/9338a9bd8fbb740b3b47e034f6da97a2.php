<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR USUARIO'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h1>USUARIOS</h1>
<img class="logo_banner"src="../../img/LO1.png" alt="Image 2">
</center>


<?php if(session('roles')->codigo_rol>=0): ?>
<div class="container ">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                        <?php endif; ?>

                        <form method="post" action="<?php echo e(route('usuarios.update',$matriz['depen']->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                             <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($matriz['depen']->id); ?>">
                            <div class="form-group">
                                <label for="nombre_apellido">Nombres y Apellidos</label>
                                <input type="text" name="nombre_apellido" id="nombre_apellido" class="form-control" value="<?php echo e($matriz['depen']->nombre_apellido); ?>" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="usuario">Nombre de Usuario</label>
                                <input type="text" name="usuario" id="usuario" class="form-control" value="<?php echo e($matriz['depen']->usuario); ?>">
                            </div>
                            <div class="form-group">
                                <label for="correo">Email</label>
                                <input type="email" id="correo" name="correo" class="form-control" value="<?php echo e($matriz['depen']->correo); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="clave">Password</label>
                                <input type="password" id="clave" name="clave" class="form-control" value="<?php echo e($matriz['depen']->clave); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="id_roles">Selecciona un Rol:</label>
                                <select name="id_roles" id="id_roles" class="form-control">
                                    <?php $__currentLoopData = $matriz['datos']['Role']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dato->id); ?>"
                                            <?php echo e($matriz['depen']->id_roles== $dato->id ? 'selected' : ''); ?>>
                                            <?php echo e($dato->nombre_rol); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Actualizar</button>
                        </form>
                        <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




  </tbody>
</table>
</div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulProyect\webpolicial\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>