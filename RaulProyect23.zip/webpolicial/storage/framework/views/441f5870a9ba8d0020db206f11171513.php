<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'CREAR DISTRITO'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>CREAR DISTRITO</h1>
        <img class="logo_banner" src="../img/LO1.png" alt="Image 2">
    </center>


<div class="container">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('distritos.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="nombre_distrito">Nombres de distrito</label>
                                <input type="text" name="nombre_distrito" id="nombre_distrito" class="form-control" placeholder="" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="codigo_distrito">Codigo de distrito</label>
                                <input type="text" name="codigo_distrito" id="codigo_distrito" class="form-control" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="numero_distrito">Numero de distrito</label>
                                <input type="text" id="numero_distrito" name="numero_distrito" class="form-control" required>
                            </div>
                            <?php  $user = session('user') ?>
                            <div class="form-group">

                                <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo $user->__get('id');?>"required style="display: none;"readonly>
                            </div>

                            <button type="submit" class="btn btn-primary">Crear</button>
                        </form>
                        <a href="<?php echo e(route('distritos.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulProyect\webpolicial\resources\views/distritos/create.blade.php ENDPATH**/ ?>