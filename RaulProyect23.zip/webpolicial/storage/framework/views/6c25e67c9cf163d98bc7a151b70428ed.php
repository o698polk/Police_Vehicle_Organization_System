<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR CIRCUITOS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h1>CIRCUITOS</h1>
<img class="logo_banner"src="../../img/LO1.png" alt="Image 2">
</center>
</div>

<?php if(session('roles')->codigo_rol>=0): ?>
<div class="container ">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                        <?php endif; ?>

                        <form method="post" action="<?php echo e(route('vehiculos.update',$matriz['depen']->id)); ?>">
                            <?php echo method_field('PUT'); ?>
                             <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($matriz['depen']->id); ?>">

                            <div class="form-group">
                                <label for="tipo_vehiculo">Tipo Vehiculo</label>
                                <input type="text" name="tipo_vehiculo" id="tipo_vehiculo" class="form-control" value="<?php echo e($matriz['depen']->tipo_vehiculo); ?>" required >
                            </div>
                            <div class="form-group">
                                <label for="placa">Placa</label>
                                <input type="text" name="placa" id="placa" class="form-control" value="<?php echo e($matriz['depen']->placa); ?>" required >
                            </div>
                            <div class="form-group">
                                <label for="chasis">Chasis</label>
                                <input type="text" name="chasis" id="chasis" class="form-control" value="<?php echo e($matriz['depen']->chasis); ?>" required >
                            </div>
                            <div class="form-group">
                                <label for="marca">Marca</label>
                                <input type="text" name="marca" id="marca" class="form-control" value="<?php echo e($matriz['depen']->marca); ?>" required >
                            </div>
                            <div class="form-group">
                                <label for="modelo">Modelo</label>
                                <input type="text" name="modelo" id="modelo" class="form-control" value="<?php echo e($matriz['depen']->modelo); ?>"required>
                            </div>
                            <div class="form-group">
                                <label for="motor">Motor</label>
                                <input type="text" id="motor" name="motor" class="form-control" value="<?php echo e($matriz['depen']->motor); ?>"required>
                            </div>
                            <div class="form-group">
                                <label for="kilometraje">Kilometraje</label>
                                <input type="text" id="kilometraje" name="kilometraje" class="form-control" value="<?php echo e($matriz['depen']->kilometraje); ?>"required>
                            </div>
                            <div class="form-group">
                                <label for="cilindraje">Cilindraje</label>
                                <input type="text" id="cilindraje" name="cilindraje" class="form-control" value="<?php echo e($matriz['depen']->cilindraje); ?>"required>
                            </div>
                            <div class="form-group">
                                <label for="capacidad_carga">Capacidad Carga</label>
                                <input type="text" id="capacidad_carga" name="capacidad_carga" class="form-control" value="<?php echo e($matriz['depen']->capacidad_carga); ?>"required>
                            </div>
                            <div class="form-group">
                                <label for="capacidad_pasajeros">Capacidad Pasajeros</label>
                                <input type="text" id="capacidad_pasajeros" name="capacidad_pasajeros" class="form-control" value="<?php echo e($matriz['depen']->capacidad_pasajeros); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="id_dependencia">Selecciona un subcircuito:</label>
                                <select name="id_dependencia" id="id_dependencia" class="form-control">
                                    <option value="<?php echo e($matriz['recoor']->id); ?>" selected>
                                        <?php echo e($matriz['recoor']->Subcircuito->nombre_subcircuito); ?>

                                    </option>

                                    <?php $__currentLoopData = $matriz['datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->Subcircuito->nombre_subcircuito); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <?php  $user = session('user') ?>
                            <div class="form-group">

                                <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo e($matriz['depen']->id_usuario); ?>"required style="display: none;"readonly>
                            </div>
                            <button type="submit" class="btn btn-primary">Actualizar</button>
                        </form>
                        <a href="<?php echo e(route('vehiculos.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




  </tbody>
</table>

</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulProyect\webpolicial\resources\views/vehiculos/edit.blade.php ENDPATH**/ ?>