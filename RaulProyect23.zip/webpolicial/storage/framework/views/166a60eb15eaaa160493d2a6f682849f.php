<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'POLICIA NACIONAL'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h2>PANEL DE CONTROL</h2>
<img class="logo_banner"src="img/LO1.png" alt="Image 2">
</center>
<style>
.square-button {
  display: inline-block;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  color: #000000;
  background-color: white;
  border: 1px solid #000000;
  border-radius: 0;
  cursor: pointer;
}
</style>

<div class="container">
  <div class="row">

  <?php  $user = session('user') ?>
  <?php  if ($user->__get('rol') >= 2)
  {?>
    <div class="col-sm square-button">
    <a href="<?php echo e(route('usuarios.index')); ?>" class="btn_modulos">USUARIOS</a>
    </div>
    <div class="col-sm square-button">
    <a href="<?php echo e(route('distritos.index')); ?>" class="btn_modulos">DISTRITO</a>
    </div>
    <div class="col-sm square-button">
    <a href="<?php echo e(route('circuitos.index')); ?>" class="btn_modulos">CIRCUITOS</a>
    </div>
    <div class="col-sm square-button">
    <a href="" class="btn_modulos">SUBDISTRITOS </a>
    </div>
  <?php }?>
  <?php  if ($user->__get('rol') >= 0)
  {?>
    <div class="col-sm square-button">
    <a href="distrito" class="btn_modulos">REPORTES</a>
    </div>
    <?php }?>
    <?php  if ($user->__get('rol') >=1)
  {?>
    <div class="col-sm square-button">
    <a href="distrito" class="btn_modulos">DOCUMENTOS</a>
    </div>
    <?php }?>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulPoryect\webpolicial\resources\views/extens/dashboard.blade.php ENDPATH**/ ?>