<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR CIRCUITOS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h1>CIRCUITOS</h1>
<img class="logo_banner"src="../../img/LO1.png" alt="Image 2">
</center>
</div>

<?php if(session('user')->rol==2): ?>
<div class="container ">
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

                        <?php endif; ?>

                        <form method="post" action="<?php echo e(route('circuitos.update',$datos['id'])); ?>">
                            <?php echo method_field('PUT'); ?>
                             <?php echo csrf_field(); ?>

                            <input type="hidden" name="id" value="<?php echo e($datos['id']); ?>">

                            <div class="form-group">
                                <label for="nombre_circuito">Nombres de circuito</label>
                                <input type="text" name="nombre_circuito" id="nombre_circuito" class="form-control"value="<?php echo e($datos['nombre_circuito']); ?>" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="codigo_circuito">Codigo de circuito</label>
                                <input type="text" name="codigo_circuito" id="codigo_circuito" class="form-control" value="<?php echo e($datos['codigo_circuito']); ?>"required >
                            </div>
                            <div class="form-group">
                                <label for="numero_circuito">Numero de circuito</label>
                                <input type="text" id="numero_circuito" name="numero_circuito" class="form-control"  value="<?php echo e($datos['numero_circuito']); ?>" required>
                            </div>
                            <?php  $user = session('user') ?>
                            <div class="form-group">

                                <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo e($datos['id_usuario']); ?>"required style="display: none;"readonly>
                            </div>
                            <button type="submit" class="btn btn-primary">Actualizar</button>
                        </form>
                        <a href="<?php echo e(route('circuitos.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>




  </tbody>
</table>

</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulPoryect\webpolicial\resources\views/circuitos/edit.blade.php ENDPATH**/ ?>