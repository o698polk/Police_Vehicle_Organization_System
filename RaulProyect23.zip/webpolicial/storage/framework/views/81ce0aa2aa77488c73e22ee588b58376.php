<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'POLICIA NACIONAL'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
<center>
<h1>PANEL DE CONTROL (ADMINITRACION)</h1>
<img class="logo_banner"src="img/LO1.png" alt="Image 2">
</center>
<style>
.modulos{
    width: 300px;
    height: 100px;
    margin: 15px;
    padding: 5px;
    background-color: rgb(2,0, 1);
    border-radius: 5px;
}
.btn_modulos{
 width: 98%;
 padding: 5px;
 margin: 5px;
 display: flex;
height: 80%;
 border: 1px solid gray;

 text-align: center;
 border-radius: 5px;
}
</style>

<div class="container">
  <div class="row">
    <div class="col-sm modulos">
    <a href="usuarios" class="btn_modulos">USUARIOS</a>
    </div>
    <div class="col-sm modulos">
    <a href="distrito" class="btn_modulos">DISTRITO</a>
    </div>
    <div class="col-sm modulos">
    <a href="distrito" class="btn_modulos">DISTRITO</a>
    </div>
  </div>
</div>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulPoryect\webpolicial\resources\views/dashboard.blade.php ENDPATH**/ ?>