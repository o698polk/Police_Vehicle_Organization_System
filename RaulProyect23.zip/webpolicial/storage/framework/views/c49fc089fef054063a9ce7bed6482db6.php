<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'DISTRITOS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>CIRCUITOS</h1>
        <img class="logo_banner" src="../../img/LO1.png" alt="Image 2">
    </center>
</div>

<a href="<?php echo e(route('circuitos.create')); ?> " class="btn btn-primary">Crear Circuito</a>
<?php if(session('user')->rol==2): ?>
<div class="container ">
    <table class="table boder_bar btn_modulos">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre de circuito</th>
                <th>Codigo de circuito</th>
                <th>Numero de circuito</th>
                <th>Id de Usuario que lo creo</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($dato['id']); ?></td>
                <td><?php echo e($dato['nombre_circuito']); ?></td>
                <td><?php echo e($dato['codigo_circuito']); ?></td>
                <td><?php echo e($dato['numero_circuito']); ?></td>
                <td><?php echo e($dato['id_usuario']); ?></td>
                <td><a class="btn btn-primary" href="<?php echo e(route('circuitos.edit',$dato['id'])); ?>">Editar</a></td>
                <td>
                    <form id="deleteForm" action="<?php echo e(route('circuitos.destroy',$dato['id'])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger"onclick="confirmDelete(event)">Eliminar</button>
                    </form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulPoryect\webpolicial\resources\views/circuitos/index.blade.php ENDPATH**/ ?>