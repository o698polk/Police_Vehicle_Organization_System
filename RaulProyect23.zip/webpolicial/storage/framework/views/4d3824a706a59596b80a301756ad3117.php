<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'EDITAR SUBCIRCUITOS'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->


<?php $__env->startSection('content'); ?>
<br><br><br><br><br><br>
<style>
   body {
        font-family: "Arial", sans-serif;
        margin: 0;
        padding: 0;
    }
    .cvt {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: white;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        color: black;
    }

    .section-containert {
        border: 1px solid #ccc;
        padding: 10px;
        margin-bottom: 20px;
    }

    .section-titlet {
        font-size: 20px;
        background-color: #333;
        color: white;
        padding: 5px;
        margin: 0;
    }

    .section-contentt {
        padding: 10px;
    }

    .gray-backgroundt {
        background-color: #eee;
    }

    .font-businesst {
        font-family: "Your-Font-Here", sans-serif; /* Reemplaza "Your-Font-Here" con la fuente que desees */
    }
</style>

<!--<button id="capturaButton" class="btn btn-primary">FINALIZAR</button>--->

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
<script>
    document.getElementById('capturaButton').addEventListener('click', function () {
        var cvContent = document.querySelector('.cvt');
        
        // Usar html2canvas para capturar la captura de pantalla
        html2canvas(cvContent).then(function(canvas) {
            // Convertir el lienzo en una imagen
            var imgData = canvas.toDataURL('image/png');
            
            // Crear un elemento de imagen y mostrar la captura en una ventana emergente
            var img = new Image();
            img.src = imgData;
            
            var popup = window.open('', '_blank');
            popup.document.open();
            popup.document.write('<html><head><title>Captura de Pantalla</title></head><body>');
            popup.document.write('<h1>Captura de Pantalla</h1>');
            popup.document.write('<img src="' + imgData + '" />');
            popup.document.write('</body></html>');
            popup.document.close();
            
            // Imprimir la ventana emergente
            popup.print();
        });
    });
</script>

<button id="imprimirButton" class="btn btn-primary">FINALIZAR</button>

<script>
    document.getElementById('imprimirButton').addEventListener('click', function () {
        var cvContent = document.querySelector('#ctvw');
        var newWindow = window.open('', '_blank');
        newWindow.document.open();
        newWindow.document.write('<html><head><title>ORDEN DE TRABAJO Y MANTENIMIENTO </title></head><body>');
        newWindow.document.write('<style>.cv{max-width:800px;margin:0 auto;padding:20px;background-color:white;box-shadow:0 0 10px rgba(0,0,0,0.1);color:black;}.cv *{font-family:"Arial",sans-serif;}.section-container{border:1px solid #ccc;padding:10px;margin-bottom:20px;}.section-title{font-size:20px;background-color:#333;color:white;padding:5px;margin:0;}.section-content{padding:10px;}.gray-background{background-color:#eee;}.font-business{font-family:"Your-Font-Here",sans-serif;}</style>');
        newWindow.document.write('<h1>MANTENIMIENTO</h1>');
        newWindow.document.write(cvContent.innerHTML);
        newWindow.document.write('</body></html>');
        newWindow.document.close();
        newWindow.print();
        newWindow.close();
    });
</script>
<?php if(session('roles')->codigo_rol >= 0): ?>
<div class="cvt" id="ctvw">
    <div class="section-containert">
        <h2 class="section-titlet font-businesst">ORDEN DE TRABAJO</h2>
        <div class="section-contentt">
            <p><strong>ASUNTO:</strong> <?php echo e($matriz['datos']->asunto); ?></p>
            <p><strong>Detalle:</strong> <?php echo e($matriz['datos']->detalle); ?></p>
            <p><strong>Prevención:</strong> <?php echo e($matriz['datos']->prevencion); ?></p>
        </div>
    </div>

    <div class="section-containert gray-backgroundt">
        <h2 class="section-titlet font-businesst">QUIEN SOLICITA</h2>
        <div class="section-contentt">
            <p><strong>Nombre:</strong> <?php echo e($matriz['depen']->Solicitudmantenimineto['nombre_apellido']); ?></p>
            <p><strong>Cédula:</strong> <?php echo e($matriz['depen']->Solicitudmantenimineto['identificacion']); ?></p>
            <p><strong>Fecha de la solicitud:</strong> <?php echo e($matriz['depen']->Solicitudmantenimineto['created_at']); ?></p>
        </div>
    </div>

    <div class="section-containert">
        <h2 class="section-titlet font-businesst">VEHÍCULO</h2>
        <div class="section-contentt">
            <p><strong>Tipo:</strong> <?php echo e($matriz['depen']->Vehiculo['tipo_vehiculo']); ?></p>
            <p><strong>Placa:</strong> <?php echo e($matriz['datos']->Vehiculo['placa']); ?></p>
            <p><strong>Kilometraje:</strong> <?php echo e($matriz['datos']->Vehiculo['kilometraje']); ?></p>
        </div>
    </div>

    <div class="section-containert gray-backgroundt">
        <h2 class="section-titlet font-businesst">QUIEN RETIRA</h2>
        <div class="section-contentt">
            <p><strong>Nombre:</strong> <?php echo e($matriz['datos']->Personal['nombre_apellido']); ?></p>
            <p><strong>Cédula:</strong> <?php echo e($matriz['datos']->Personal['identificacion']); ?></p>
        </div>
    </div>

    <div class="section-containert">
        <h2 class="section-titlet font-businesst">MANTENIMIENTO</h2>
        <div class="section-contentt">
            <p><strong>Tipo:</strong> <?php echo e($matriz['datos']->Tipomantenimento['tipo_mantenineto']); ?></p>
            <p><strong>Fecha de Orden de Trabajo:</strong> <?php echo e($matriz['datos']->created_at); ?></p>
            <?php if($matriz['datos']->Tipomantenimento['tipo_mantenineto'] == 'Mantenimiento 1' ||
                $matriz['datos']->Tipomantenimento['tipo_mantenineto'] == 'Motocicletas' ||
                $matriz['datos']->Tipomantenimento['tipo_mantenineto'] == 'Mantenimiento 2' ||
                $matriz['datos']->Tipomantenimento['tipo_mantenineto'] == 'Mantenimiento 3'): ?>
                <p><strong>Precio Subtotal:</strong> <?php echo e($matriz['datos']->Tipomantenimento['precio']); ?></p>
                <p><strong>IVA:</strong> <?php echo e(($matriz['datos']->Tipomantenimento['precio']*0.12)); ?></p>
                <p><strong>Precio Total:</strong> <?php echo e($matriz['datos']->Tipomantenimento['precio']+($matriz['datos']->Tipomantenimento['precio']*0.12)); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="section-containert gray-backgroundt">
        <h2 class="section-titlet font-businesst">FECHA DE RETIRO</h2>
        <div class="section-contentt">
            <p><strong>Fecha:</strong> <?php echo e($matriz['datos']->updated_at); ?></p>
        </div>
    </div>

    <div class="section-containert">
        <h2 class="section-titlet font-businesst">ADMINISTRADOR</h2>
        <div class="section-contentt">
            <p><strong>Nombre:</strong> <?php echo e($matriz['datos']->Usuario['nombre_apellido']); ?></p>
        </div>
    </div>
</div>
<?php endif; ?>
<br><br><br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Downloads\webpolicial0-3\webpolicial\resources\views/mantenimiento/orden.blade.php ENDPATH**/ ?>