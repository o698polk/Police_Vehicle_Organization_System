<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'CREAR REPORTE ATC'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>GENERAR REPORTE </h1>
        <img class="logo_banner" src="../img/LO1.png" alt="Image 2">
    </center>


<div class="container">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('reporte_eventos.store')); ?>"id="formcontrol">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="apellidos">Apellidos:</label>
                                <input type="text" class="form-control" id="apellidos" name="apellidos">
                            </div>
                            <div class="form-group">
                                <label for="nombres">Nombres:</label>
                                <input type="text" class="form-control" id="nombres" name="nombres">
                            </div>
                            <div class="form-group">
                                <label for="contacto">Contactos:</label>
                                <input type="text" class="form-control" id="contacto" name="contacto">
                            </div>

                            <div class="form-group">
                                <label for="tipo">Selecciona un Tipo:</label>
                                <select class="form-control" id="tipo" name="tipo">

                                    <option value="Reclamo">Reclamo</option>
                                    <option value="Sugerencia">Sugerencia</option>

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="detalle">Detalle:</label>
                                <input type="text" class="form-control" id="detalle" name="detalle">
                            </div>
                            <div class="form-group">
                                <label for="id_circuito">Selecciona un Circuito:</label>
                                <select class="form-control" id="id_circuito" name="id_circuito">
                                    <?php $__currentLoopData = $datos['Circuito']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato2->id); ?>"><?php echo e($dato2->nombre_circuito); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="id_subcircuito">Selecciona un Subircuito:</label>
                                <select class="form-control" id="id_subcircuito" name="id_subcircuito">

                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Crear</button>
                        </form>
                        <a href="<?php echo e(route('reporte_eventos.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Polk Vernaza\Documents\InfoCode\PHP\proyectos\webpolicial\resources\views/reporte_eventos/reportar.blade.php ENDPATH**/ ?>