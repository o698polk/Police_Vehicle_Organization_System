<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'CREAR DEPENDENCIA'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>CREAR DEPENDENCIA</h1>
        <img class="logo_banner" src="../img/LO1.png" alt="Image 2">
    </center>


<div class="container">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">

                    <div class="card-body">
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('dependencias.store')); ?>" id="formcontrol">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="provincia">Selecciona una Provincia:</label>
                                <select class="form-control" id="provincia" name="provincia">
                                    <option value="LOJA">LOJA</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="id_distrito">Selecciona un Distrito:</label>
                                <select class="form-control" id="id_distrito" name="id_distrito">
                                    <?php $__currentLoopData = $datos['Distrito']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->nombre_distrito); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="id_parroquia">Selecciona una Parroquia:</label>
                                <select class="form-control" id="id_parroquia" name="id_parroquia">

                                    <?php $__currentLoopData = $datos['Parroquia']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dato->id); ?>"><?php echo e($dato->nombre_parroquia); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group" id="CircuitoSelect">
                                <label for="id_circuito">Selecciona una Circuito:</label>
                                <select class="form-control" id="id_circuito" name="id_circuito">

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="id_subcircuito">Selecciona un Subcircuito:</label>
                                <select class="form-control" id="id_subcircuito" name="id_subcircuito">

                                </select>
                            </div>

                            <?php  $user = session('user') ?>
                            <div class="form-group">

                                <input type="hidden" id="id_usuario" name="id_usuario" class="form-control" value="<?php echo $user->__get('id');?>"required style="display: none;"readonly>
                            </div>

                            <button type="submit" class="btn btn-primary">Crear</button>
                        </form>
                        <a href="<?php echo e(route('dependencias.index')); ?>" class="btn btn-defaul">Regresar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulProyect\webpolicial\resources\views/dependencias/create.blade.php ENDPATH**/ ?>