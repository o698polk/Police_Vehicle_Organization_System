<!-- DESPLEGANDO TODA LA PLATILLA REALIZADA--->


<!-- DESPLEGANDO EL TITULO DE ESTA PAGINA-->
<?php $__env->startSection('title', 'ROLES'); ?>

<!-- DESPLEGANDO TODO EL CONTENIDO DE ESTA PAGINA--->
<?php $__env->startSection('content'); ?>
<div class="containe  page_style">
    <center>
        <h1>CIRCUITOS</h1>
        <img class="logo_banner" src="../../img/LO1.png" alt="Image 2">
    </center>
</div>
<br>
<form method="POST"  action="<?php echo e(route('buscarroles')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="form-group">

        <input type="text" name="filtro_nombre" placeholder="Codigo Circuito"class="form-control" >
    </div>

    <!-- Agrega más campos de filtro según tus necesidades -->
    <button type="submit" class="btn btn-info">Buscar</button>
</form>
<a href="<?php echo e(route('roles.create')); ?> " class="btn btn-primary">Crear Roles</a>
<button onclick="imprimirDiv()" class="btn btn-success">Imprimir</button>
<?php if(session('roles')->codigo_rol>=0): ?>
<div class="container "id="reportid">
    <table class="table boder_bar btn_modulos">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre Rol</th>
                <th>Codigo Rol</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($dato['id']); ?></td>
                <td><?php echo e($dato['nombre_rol']); ?></td>
                <td><?php echo e($dato['codigo_rol']); ?></td>

                <td><a class="btn btn-primary" href="<?php echo e(route('roles.edit',$dato['id'])); ?>">Editar</a></td>

                <td>
                    <form class="deleteForm" action="<?php echo e(route('roles.destroy',$dato['id'])); ?>" id_eliminar="<?php echo e($dato['id']); ?>"method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </form>
                 </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($datos->links()); ?>

</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RaulProyect\webpolicial\resources\views/roles/index.blade.php ENDPATH**/ ?>